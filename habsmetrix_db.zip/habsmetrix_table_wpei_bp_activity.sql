
-- --------------------------------------------------------

--
-- Table structure for table `wpei_bp_activity`
--

CREATE TABLE `wpei_bp_activity` (
  `id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `component` varchar(75) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `type` varchar(75) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `action` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `primary_link` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `item_id` bigint(20) NOT NULL,
  `secondary_item_id` bigint(20) DEFAULT NULL,
  `date_recorded` datetime NOT NULL,
  `hide_sitewide` tinyint(1) DEFAULT '0',
  `mptt_left` int(11) NOT NULL DEFAULT '0',
  `mptt_right` int(11) NOT NULL DEFAULT '0',
  `is_spam` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wpei_bp_activity`
--

INSERT INTO `wpei_bp_activity` (`id`, `user_id`, `component`, `type`, `action`, `content`, `primary_link`, `item_id`, `secondary_item_id`, `date_recorded`, `hide_sitewide`, `mptt_left`, `mptt_right`, `is_spam`) VALUES
(1, 1, 'members', 'last_activity', '', '', '', 0, NULL, '2019-01-15 12:59:10', 0, 0, 0, 0),
(2, 4, 'blogs', 'new_blog_post', '<a href=\"http://localhost:8888/habsmetrix/members/darelllemos84/\">darelllemos84</a> wrote a new post, <a href=\"http://localhost:8888/habsmetrix/?p=631\">Iusto et ut explicabo assumenda quia</a>', 'Sed eum omnis provident ea. Deleniti repellendus excepturi ut aliquam assumenda illum. Incidunt enim eaque omnis\r\n\r\n 	Temporibus\r\n 	Quisquam sit aut aperiam\r\n 	In minus maiores sed\r\n\r\nDebitis non sed sunt. Alias [&hellip;] <img src=\"http://localhost:8888/habsmetrix/wp-content/uploads/2018/10/1efc26bb-fe5c-3906-bec8-c5d00f604eaa-300x200.jpg\"/>', 'http://localhost:8888/habsmetrix/?p=631', 1, 631, '2018-10-27 07:24:47', 0, 0, 0, 0),
(3, 1, 'blogs', 'new_blog_post', '<a href=\"http://localhost:8888/habsmetrix/members/nx2tx/\">Philip</a> wrote a new post, <a href=\"http://localhost:8888/habsmetrix/?p=646\">Sint nihil harum architecto qui saepe</a>', '\r\n\r\n\r\n\r\nRerum officia numquam necessitatibus qui. Ratione aut suscipit itaque omnis est sapiente\r\nMollitia at cum rerum ut. Est fugiat ut. Aut ut explicabo aut quibusdam quasi. Ratione qui praesentium quam. [&hellip;] <img src=\"http://localhost:8888/habsmetrix/wp-content/uploads/2018/10/6d705b77-8695-3e67-be29-6e131f47ab4f-300x169.jpg\"/>', 'http://localhost:8888/habsmetrix/?p=646', 1, 646, '2018-10-31 14:32:46', 0, 0, 0, 0),
(4, 8, 'members', 'last_activity', '', '', '', 0, NULL, '2018-11-27 18:19:10', 0, 0, 0, 0);
