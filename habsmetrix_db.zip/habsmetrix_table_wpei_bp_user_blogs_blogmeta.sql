
-- --------------------------------------------------------

--
-- Table structure for table `wpei_bp_user_blogs_blogmeta`
--

CREATE TABLE `wpei_bp_user_blogs_blogmeta` (
  `id` bigint(20) NOT NULL,
  `blog_id` bigint(20) NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wpei_bp_user_blogs_blogmeta`
--

INSERT INTO `wpei_bp_user_blogs_blogmeta` (`id`, `blog_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'url', 'http://localhost:8888/habsmetrix'),
(2, 1, 'name', 'Habsmetrix'),
(3, 1, 'description', 'Advanced analytics of the Montreal Canadiens fan base'),
(4, 1, 'last_activity', '2018-11-08 14:17:55'),
(5, 1, 'close_comments_for_old_posts', '0'),
(6, 1, 'close_comments_days_old', '14'),
(7, 1, 'thread_comments_depth', '5'),
(8, 1, 'comment_moderation', '1');
