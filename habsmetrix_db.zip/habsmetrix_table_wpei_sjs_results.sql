
-- --------------------------------------------------------

--
-- Table structure for table `wpei_sjs_results`
--

CREATE TABLE `wpei_sjs_results` (
  `id` mediumint(9) NOT NULL,
  `surveyId` mediumint(9) NOT NULL,
  `json` text COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
