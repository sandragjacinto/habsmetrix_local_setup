
-- --------------------------------------------------------

--
-- Table structure for table `wpei_survey_ratings`
--

CREATE TABLE `wpei_survey_ratings` (
  `ID` bigint(20) NOT NULL,
  `survey_id` bigint(20) NOT NULL,
  `survey_type` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `date` datetime NOT NULL,
  `answer` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `answer_array` mediumblob NOT NULL,
  `relevance` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `user_ip` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `user_id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wpei_survey_ratings`
--

INSERT INTO `wpei_survey_ratings` (`ID`, `survey_id`, `survey_type`, `date`, `answer`, `answer_array`, `relevance`, `user_ip`, `user_id`) VALUES
(6, 1131, 'STATEMENT', '2019-01-31 09:15:23', '-0.5', 0x733a313a222d223b, '-1', '::1', 1),
(7, 929, 'MCT', '2019-01-31 10:08:43', 'answer_2', 0x733a313a222d223b, '1', '::1', 1),
(8, 914, 'RANGE', '2019-01-31 11:06:25', '5', 0x733a313a222d223b, '-1', '::1', 1),
(9, 1172, 'STATEMENT', '2019-01-31 11:03:57', '0.5', 0x733a313a222d223b, '1', '::1', 1),
(10, 916, 'ORDER', '2019-01-31 11:45:17', '-', 0x613a343a7b693a303b733a373a22696d6167655f31223b693a313b733a373a22696d6167655f33223b693a323b733a373a22696d6167655f32223b693a333b733a373a22696d6167655f34223b7d, '-1', '::1', 1),
(11, 961, 'MCI', '2019-01-31 11:44:51', 'image_2', 0x733a313a222d223b, '1', '::1', 1),
(12, 915, 'MCT', '2019-01-31 11:07:01', 'answer_3', 0x733a313a222d223b, '1', '::1', 1),
(13, 1177, 'STATEMENT', '2019-01-31 11:44:21', '-0.5', 0x733a313a222d223b, '1', '::1', 1);
