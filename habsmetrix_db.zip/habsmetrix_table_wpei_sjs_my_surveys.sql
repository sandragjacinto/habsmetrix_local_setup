
-- --------------------------------------------------------

--
-- Table structure for table `wpei_sjs_my_surveys`
--

CREATE TABLE `wpei_sjs_my_surveys` (
  `id` mediumint(9) NOT NULL,
  `name` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `json` text COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wpei_sjs_my_surveys`
--

INSERT INTO `wpei_sjs_my_surveys` (`id`, `name`, `json`) VALUES
(2, 'New Survey', '{\\\"title\\\":\\\"test\\\",\\\"pages\\\":[{\\\"name\\\":\\\"page1\\\",\\\"elements\\\":[{\\\"type\\\":\\\"imagepicker\\\",\\\"name\\\":\\\"question2\\\",\\\"choices\\\":[{\\\"value\\\":\\\"lion\\\",\\\"imageLink\\\":\\\"https://surveyjs.io/Content/Images/examples/image-picker/lion.jpg\\\"}]},{\\\"type\\\":\\\"rating\\\",\\\"name\\\":\\\"question1\\\",\\\"title\\\":\\\"how satisfied are you with this player ?\\\",\\\"isRequired\\\":true}]}]}'),
(3, 'New Survey', '{\\\"pages\\\":[{\\\"name\\\":\\\"page1\\\",\\\"elements\\\":[{\\\"type\\\":\\\"rating\\\",\\\"name\\\":\\\"question1\\\",\\\"rateValues\\\":[{\\\"value\\\":\\\"item1\\\",\\\"text\\\":\\\"85000\\\"},{\\\"value\\\":\\\"item2\\\",\\\"text\\\":\\\"95000\\\"},{\\\"value\\\":\\\"item3\\\",\\\"text\\\":\\\"12000000\\\"}],\\\"minRateDescription\\\":\\\"75000 \\\",\\\"maxRateDescription\\\":\\\" 13000000\\\"},{\\\"type\\\":\\\"matrix\\\",\\\"name\\\":\\\"question4\\\",\\\"columns\\\":[\\\"Column 1\\\",\\\"Column 2\\\",\\\"Column 3\\\"],\\\"rows\\\":[\\\"Row 1\\\",\\\"Row 2\\\"]},{\\\"type\\\":\\\"imagepicker\\\",\\\"name\\\":\\\"question2\\\",\\\"choices\\\":[{\\\"value\\\":\\\"lion\\\",\\\"imageLink\\\":\\\"https://surveyjs.io/Content/Images/examples/image-picker/lion.jpg\\\"},{\\\"value\\\":\\\"giraffe\\\",\\\"imageLink\\\":\\\"https://surveyjs.io/Content/Images/examples/image-picker/giraffe.jpg\\\"},{\\\"value\\\":\\\"panda\\\",\\\"imageLink\\\":\\\"https://surveyjs.io/Content/Images/examples/image-picker/panda.jpg\\\"},{\\\"value\\\":\\\"camel\\\",\\\"imageLink\\\":\\\"https://surveyjs.io/Content/Images/examples/image-picker/camel.jpg\\\"}]},{\\\"type\\\":\\\"imagepicker\\\",\\\"name\\\":\\\"question3\\\",\\\"choices\\\":[{\\\"value\\\":\\\"lion\\\",\\\"imageLink\\\":\\\"https://surveyjs.io/Content/Images/examples/image-picker/lion.jpg\\\"},{\\\"value\\\":\\\"giraffe\\\",\\\"imageLink\\\":\\\"https://surveyjs.io/Content/Images/examples/image-picker/giraffe.jpg\\\"},{\\\"value\\\":\\\"panda\\\",\\\"imageLink\\\":\\\"https://surveyjs.io/Content/Images/examples/image-picker/panda.jpg\\\"},{\\\"value\\\":\\\"camel\\\",\\\"imageLink\\\":\\\"https://surveyjs.io/Content/Images/examples/image-picker/camel.jpg\\\"}]},{\\\"type\\\":\\\"panel\\\",\\\"name\\\":\\\"panel1\\\"}]}]}'),
(4, 'New Survey', '{\\\"pages\\\":[{\\\"name\\\":\\\"page1\\\",\\\"elements\\\":[{\\\"type\\\":\\\"imagepicker\\\",\\\"name\\\":\\\"question1\\\",\\\"choices\\\":[{\\\"value\\\":\\\"lion\\\",\\\"imageLink\\\":\\\"https://surveyjs.io/Content/Images/examples/image-picker/lion.jpg\\\"},{\\\"value\\\":\\\"giraffe\\\",\\\"imageLink\\\":\\\"https://surveyjs.io/Content/Images/examples/image-picker/giraffe.jpg\\\"},{\\\"value\\\":\\\"panda\\\",\\\"imageLink\\\":\\\"https://surveyjs.io/Content/Images/examples/image-picker/panda.jpg\\\"},{\\\"value\\\":\\\"camel\\\",\\\"imageLink\\\":\\\"https://surveyjs.io/Content/Images/examples/image-picker/camel.jpg\\\"}]}]}]}');
