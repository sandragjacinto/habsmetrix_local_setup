
--
-- Indexes for dumped tables
--

--
-- Indexes for table `wpei_bp_activity`
--
ALTER TABLE `wpei_bp_activity`
  ADD PRIMARY KEY (`id`),
  ADD KEY `date_recorded` (`date_recorded`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `item_id` (`item_id`),
  ADD KEY `secondary_item_id` (`secondary_item_id`),
  ADD KEY `component` (`component`),
  ADD KEY `type` (`type`),
  ADD KEY `mptt_left` (`mptt_left`),
  ADD KEY `mptt_right` (`mptt_right`),
  ADD KEY `hide_sitewide` (`hide_sitewide`),
  ADD KEY `is_spam` (`is_spam`);

--
-- Indexes for table `wpei_bp_activity_meta`
--
ALTER TABLE `wpei_bp_activity_meta`
  ADD PRIMARY KEY (`id`),
  ADD KEY `activity_id` (`activity_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wpei_bp_friends`
--
ALTER TABLE `wpei_bp_friends`
  ADD PRIMARY KEY (`id`),
  ADD KEY `initiator_user_id` (`initiator_user_id`),
  ADD KEY `friend_user_id` (`friend_user_id`);

--
-- Indexes for table `wpei_bp_groups`
--
ALTER TABLE `wpei_bp_groups`
  ADD PRIMARY KEY (`id`),
  ADD KEY `creator_id` (`creator_id`),
  ADD KEY `status` (`status`),
  ADD KEY `parent_id` (`parent_id`);

--
-- Indexes for table `wpei_bp_groups_groupmeta`
--
ALTER TABLE `wpei_bp_groups_groupmeta`
  ADD PRIMARY KEY (`id`),
  ADD KEY `group_id` (`group_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wpei_bp_groups_members`
--
ALTER TABLE `wpei_bp_groups_members`
  ADD PRIMARY KEY (`id`),
  ADD KEY `group_id` (`group_id`),
  ADD KEY `is_admin` (`is_admin`),
  ADD KEY `is_mod` (`is_mod`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `inviter_id` (`inviter_id`),
  ADD KEY `is_confirmed` (`is_confirmed`);

--
-- Indexes for table `wpei_bp_messages_messages`
--
ALTER TABLE `wpei_bp_messages_messages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sender_id` (`sender_id`),
  ADD KEY `thread_id` (`thread_id`);

--
-- Indexes for table `wpei_bp_messages_meta`
--
ALTER TABLE `wpei_bp_messages_meta`
  ADD PRIMARY KEY (`id`),
  ADD KEY `message_id` (`message_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wpei_bp_messages_notices`
--
ALTER TABLE `wpei_bp_messages_notices`
  ADD PRIMARY KEY (`id`),
  ADD KEY `is_active` (`is_active`);

--
-- Indexes for table `wpei_bp_messages_recipients`
--
ALTER TABLE `wpei_bp_messages_recipients`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `thread_id` (`thread_id`),
  ADD KEY `is_deleted` (`is_deleted`),
  ADD KEY `sender_only` (`sender_only`),
  ADD KEY `unread_count` (`unread_count`);

--
-- Indexes for table `wpei_bp_notifications`
--
ALTER TABLE `wpei_bp_notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `item_id` (`item_id`),
  ADD KEY `secondary_item_id` (`secondary_item_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `is_new` (`is_new`),
  ADD KEY `component_name` (`component_name`),
  ADD KEY `component_action` (`component_action`),
  ADD KEY `useritem` (`user_id`,`is_new`);

--
-- Indexes for table `wpei_bp_notifications_meta`
--
ALTER TABLE `wpei_bp_notifications_meta`
  ADD PRIMARY KEY (`id`),
  ADD KEY `notification_id` (`notification_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wpei_bp_user_blogs`
--
ALTER TABLE `wpei_bp_user_blogs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `blog_id` (`blog_id`);

--
-- Indexes for table `wpei_bp_user_blogs_blogmeta`
--
ALTER TABLE `wpei_bp_user_blogs_blogmeta`
  ADD PRIMARY KEY (`id`),
  ADD KEY `blog_id` (`blog_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wpei_bp_xprofile_data`
--
ALTER TABLE `wpei_bp_xprofile_data`
  ADD PRIMARY KEY (`id`),
  ADD KEY `field_id` (`field_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `wpei_bp_xprofile_fields`
--
ALTER TABLE `wpei_bp_xprofile_fields`
  ADD PRIMARY KEY (`id`),
  ADD KEY `group_id` (`group_id`),
  ADD KEY `parent_id` (`parent_id`),
  ADD KEY `field_order` (`field_order`),
  ADD KEY `can_delete` (`can_delete`),
  ADD KEY `is_required` (`is_required`);

--
-- Indexes for table `wpei_bp_xprofile_groups`
--
ALTER TABLE `wpei_bp_xprofile_groups`
  ADD PRIMARY KEY (`id`),
  ADD KEY `can_delete` (`can_delete`);

--
-- Indexes for table `wpei_bp_xprofile_meta`
--
ALTER TABLE `wpei_bp_xprofile_meta`
  ADD PRIMARY KEY (`id`),
  ADD KEY `object_id` (`object_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wpei_commentmeta`
--
ALTER TABLE `wpei_commentmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `comment_id` (`comment_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wpei_comments`
--
ALTER TABLE `wpei_comments`
  ADD PRIMARY KEY (`comment_ID`),
  ADD KEY `comment_post_ID` (`comment_post_ID`),
  ADD KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  ADD KEY `comment_date_gmt` (`comment_date_gmt`),
  ADD KEY `comment_parent` (`comment_parent`),
  ADD KEY `comment_author_email` (`comment_author_email`(10)),
  ADD KEY `woo_idx_comment_type` (`comment_type`);

--
-- Indexes for table `wpei_core_metrix_ratings`
--
ALTER TABLE `wpei_core_metrix_ratings`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `wpei_core_metrix_ratings_old`
--
ALTER TABLE `wpei_core_metrix_ratings_old`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `wpei_duplicator_packages`
--
ALTER TABLE `wpei_duplicator_packages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `hash` (`hash`);

--
-- Indexes for table `wpei_links`
--
ALTER TABLE `wpei_links`
  ADD PRIMARY KEY (`link_id`),
  ADD KEY `link_visible` (`link_visible`);

--
-- Indexes for table `wpei_maxbuttonsv3`
--
ALTER TABLE `wpei_maxbuttonsv3`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wpei_maxbuttons_collections`
--
ALTER TABLE `wpei_maxbuttons_collections`
  ADD PRIMARY KEY (`meta_id`);

--
-- Indexes for table `wpei_mlw_qm_audit_trail`
--
ALTER TABLE `wpei_mlw_qm_audit_trail`
  ADD PRIMARY KEY (`trail_id`);

--
-- Indexes for table `wpei_mlw_questions`
--
ALTER TABLE `wpei_mlw_questions`
  ADD PRIMARY KEY (`question_id`);

--
-- Indexes for table `wpei_mlw_quizzes`
--
ALTER TABLE `wpei_mlw_quizzes`
  ADD PRIMARY KEY (`quiz_id`);

--
-- Indexes for table `wpei_mlw_results`
--
ALTER TABLE `wpei_mlw_results`
  ADD PRIMARY KEY (`result_id`);

--
-- Indexes for table `wpei_mr_rating_item`
--
ALTER TABLE `wpei_mr_rating_item`
  ADD PRIMARY KEY (`rating_item_id`);

--
-- Indexes for table `wpei_mr_rating_item_entry`
--
ALTER TABLE `wpei_mr_rating_item_entry`
  ADD PRIMARY KEY (`rating_item_entry_id`),
  ADD KEY `ix_rating_entry` (`rating_item_entry_id`,`post_id`);

--
-- Indexes for table `wpei_mr_rating_item_entry_value`
--
ALTER TABLE `wpei_mr_rating_item_entry_value`
  ADD PRIMARY KEY (`rating_item_entry_value_id`),
  ADD KEY `ix_rating_entry` (`rating_item_entry_id`);

--
-- Indexes for table `wpei_mr_rating_subject`
--
ALTER TABLE `wpei_mr_rating_subject`
  ADD PRIMARY KEY (`rating_id`);

--
-- Indexes for table `wpei_options`
--
ALTER TABLE `wpei_options`
  ADD PRIMARY KEY (`option_id`),
  ADD UNIQUE KEY `option_name` (`option_name`);

--
-- Indexes for table `wpei_postmeta`
--
ALTER TABLE `wpei_postmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `post_id` (`post_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wpei_posts`
--
ALTER TABLE `wpei_posts`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `post_name` (`post_name`(191)),
  ADD KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  ADD KEY `post_parent` (`post_parent`),
  ADD KEY `post_author` (`post_author`);

--
-- Indexes for table `wpei_signups`
--
ALTER TABLE `wpei_signups`
  ADD PRIMARY KEY (`signup_id`),
  ADD KEY `activation_key` (`activation_key`),
  ADD KEY `user_email` (`user_email`),
  ADD KEY `user_login_email` (`user_login`,`user_email`),
  ADD KEY `domain_path` (`domain`(140),`path`(51));

--
-- Indexes for table `wpei_sjs_my_surveys`
--
ALTER TABLE `wpei_sjs_my_surveys`
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `wpei_sjs_results`
--
ALTER TABLE `wpei_sjs_results`
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `wpei_survey_ratings`
--
ALTER TABLE `wpei_survey_ratings`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `wpei_team_poll`
--
ALTER TABLE `wpei_team_poll`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `wpei_termmeta`
--
ALTER TABLE `wpei_termmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `term_id` (`term_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wpei_terms`
--
ALTER TABLE `wpei_terms`
  ADD PRIMARY KEY (`term_id`),
  ADD KEY `slug` (`slug`(191)),
  ADD KEY `name` (`name`(191));

--
-- Indexes for table `wpei_term_relationships`
--
ALTER TABLE `wpei_term_relationships`
  ADD PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  ADD KEY `term_taxonomy_id` (`term_taxonomy_id`);

--
-- Indexes for table `wpei_term_taxonomy`
--
ALTER TABLE `wpei_term_taxonomy`
  ADD PRIMARY KEY (`term_taxonomy_id`),
  ADD UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  ADD KEY `taxonomy` (`taxonomy`);

--
-- Indexes for table `wpei_uji_counter`
--
ALTER TABLE `wpei_uji_counter`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`);

--
-- Indexes for table `wpei_uji_subscriptions`
--
ALTER TABLE `wpei_uji_subscriptions`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `wpei_usermeta`
--
ALTER TABLE `wpei_usermeta`
  ADD PRIMARY KEY (`umeta_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wpei_users`
--
ALTER TABLE `wpei_users`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `user_login_key` (`user_login`),
  ADD KEY `user_nicename` (`user_nicename`),
  ADD KEY `user_email` (`user_email`);

--
-- Indexes for table `wpei_wc_download_log`
--
ALTER TABLE `wpei_wc_download_log`
  ADD PRIMARY KEY (`download_log_id`),
  ADD KEY `permission_id` (`permission_id`),
  ADD KEY `timestamp` (`timestamp`);

--
-- Indexes for table `wpei_wc_webhooks`
--
ALTER TABLE `wpei_wc_webhooks`
  ADD PRIMARY KEY (`webhook_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `wpei_woocommerce_api_keys`
--
ALTER TABLE `wpei_woocommerce_api_keys`
  ADD PRIMARY KEY (`key_id`),
  ADD KEY `consumer_key` (`consumer_key`),
  ADD KEY `consumer_secret` (`consumer_secret`);

--
-- Indexes for table `wpei_woocommerce_attribute_taxonomies`
--
ALTER TABLE `wpei_woocommerce_attribute_taxonomies`
  ADD PRIMARY KEY (`attribute_id`),
  ADD KEY `attribute_name` (`attribute_name`(20));

--
-- Indexes for table `wpei_woocommerce_downloadable_product_permissions`
--
ALTER TABLE `wpei_woocommerce_downloadable_product_permissions`
  ADD PRIMARY KEY (`permission_id`),
  ADD KEY `download_order_key_product` (`product_id`,`order_id`,`order_key`(16),`download_id`),
  ADD KEY `download_order_product` (`download_id`,`order_id`,`product_id`),
  ADD KEY `order_id` (`order_id`);

--
-- Indexes for table `wpei_woocommerce_log`
--
ALTER TABLE `wpei_woocommerce_log`
  ADD PRIMARY KEY (`log_id`),
  ADD KEY `level` (`level`);

--
-- Indexes for table `wpei_woocommerce_order_itemmeta`
--
ALTER TABLE `wpei_woocommerce_order_itemmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `order_item_id` (`order_item_id`),
  ADD KEY `meta_key` (`meta_key`(32));

--
-- Indexes for table `wpei_woocommerce_order_items`
--
ALTER TABLE `wpei_woocommerce_order_items`
  ADD PRIMARY KEY (`order_item_id`),
  ADD KEY `order_id` (`order_id`);

--
-- Indexes for table `wpei_woocommerce_payment_tokenmeta`
--
ALTER TABLE `wpei_woocommerce_payment_tokenmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `payment_token_id` (`payment_token_id`),
  ADD KEY `meta_key` (`meta_key`(32));

--
-- Indexes for table `wpei_woocommerce_payment_tokens`
--
ALTER TABLE `wpei_woocommerce_payment_tokens`
  ADD PRIMARY KEY (`token_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `wpei_woocommerce_sessions`
--
ALTER TABLE `wpei_woocommerce_sessions`
  ADD PRIMARY KEY (`session_key`),
  ADD UNIQUE KEY `session_id` (`session_id`);

--
-- Indexes for table `wpei_woocommerce_shipping_zones`
--
ALTER TABLE `wpei_woocommerce_shipping_zones`
  ADD PRIMARY KEY (`zone_id`);

--
-- Indexes for table `wpei_woocommerce_shipping_zone_locations`
--
ALTER TABLE `wpei_woocommerce_shipping_zone_locations`
  ADD PRIMARY KEY (`location_id`),
  ADD KEY `location_id` (`location_id`),
  ADD KEY `location_type_code` (`location_type`(10),`location_code`(20));

--
-- Indexes for table `wpei_woocommerce_shipping_zone_methods`
--
ALTER TABLE `wpei_woocommerce_shipping_zone_methods`
  ADD PRIMARY KEY (`instance_id`);

--
-- Indexes for table `wpei_woocommerce_tax_rates`
--
ALTER TABLE `wpei_woocommerce_tax_rates`
  ADD PRIMARY KEY (`tax_rate_id`),
  ADD KEY `tax_rate_country` (`tax_rate_country`),
  ADD KEY `tax_rate_state` (`tax_rate_state`(2)),
  ADD KEY `tax_rate_class` (`tax_rate_class`(10)),
  ADD KEY `tax_rate_priority` (`tax_rate_priority`);

--
-- Indexes for table `wpei_woocommerce_tax_rate_locations`
--
ALTER TABLE `wpei_woocommerce_tax_rate_locations`
  ADD PRIMARY KEY (`location_id`),
  ADD KEY `tax_rate_id` (`tax_rate_id`),
  ADD KEY `location_type_code` (`location_type`(10),`location_code`(20));

--
-- Indexes for table `wpei_xt_statistic`
--
ALTER TABLE `wpei_xt_statistic`
  ADD PRIMARY KEY (`ip`,`date`);

--
-- Indexes for table `wpyf_commentmeta`
--
ALTER TABLE `wpyf_commentmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `comment_id` (`comment_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wpyf_comments`
--
ALTER TABLE `wpyf_comments`
  ADD PRIMARY KEY (`comment_ID`),
  ADD KEY `comment_post_ID` (`comment_post_ID`),
  ADD KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  ADD KEY `comment_date_gmt` (`comment_date_gmt`),
  ADD KEY `comment_parent` (`comment_parent`),
  ADD KEY `comment_author_email` (`comment_author_email`(10));

--
-- Indexes for table `wpyf_links`
--
ALTER TABLE `wpyf_links`
  ADD PRIMARY KEY (`link_id`),
  ADD KEY `link_visible` (`link_visible`);

--
-- Indexes for table `wpyf_options`
--
ALTER TABLE `wpyf_options`
  ADD PRIMARY KEY (`option_id`),
  ADD UNIQUE KEY `option_name` (`option_name`);

--
-- Indexes for table `wpyf_postmeta`
--
ALTER TABLE `wpyf_postmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `post_id` (`post_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wpyf_posts`
--
ALTER TABLE `wpyf_posts`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `post_name` (`post_name`(191)),
  ADD KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  ADD KEY `post_parent` (`post_parent`),
  ADD KEY `post_author` (`post_author`);

--
-- Indexes for table `wpyf_termmeta`
--
ALTER TABLE `wpyf_termmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `term_id` (`term_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wpyf_terms`
--
ALTER TABLE `wpyf_terms`
  ADD PRIMARY KEY (`term_id`),
  ADD KEY `slug` (`slug`(191)),
  ADD KEY `name` (`name`(191));

--
-- Indexes for table `wpyf_term_relationships`
--
ALTER TABLE `wpyf_term_relationships`
  ADD PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  ADD KEY `term_taxonomy_id` (`term_taxonomy_id`);

--
-- Indexes for table `wpyf_term_taxonomy`
--
ALTER TABLE `wpyf_term_taxonomy`
  ADD PRIMARY KEY (`term_taxonomy_id`),
  ADD UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  ADD KEY `taxonomy` (`taxonomy`);

--
-- Indexes for table `wpyf_usermeta`
--
ALTER TABLE `wpyf_usermeta`
  ADD PRIMARY KEY (`umeta_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wpyf_users`
--
ALTER TABLE `wpyf_users`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `user_login_key` (`user_login`),
  ADD KEY `user_nicename` (`user_nicename`),
  ADD KEY `user_email` (`user_email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `wpei_bp_activity`
--
ALTER TABLE `wpei_bp_activity`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `wpei_bp_activity_meta`
--
ALTER TABLE `wpei_bp_activity_meta`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `wpei_bp_friends`
--
ALTER TABLE `wpei_bp_friends`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wpei_bp_groups`
--
ALTER TABLE `wpei_bp_groups`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wpei_bp_groups_groupmeta`
--
ALTER TABLE `wpei_bp_groups_groupmeta`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wpei_bp_groups_members`
--
ALTER TABLE `wpei_bp_groups_members`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wpei_bp_messages_messages`
--
ALTER TABLE `wpei_bp_messages_messages`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wpei_bp_messages_meta`
--
ALTER TABLE `wpei_bp_messages_meta`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wpei_bp_messages_notices`
--
ALTER TABLE `wpei_bp_messages_notices`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wpei_bp_messages_recipients`
--
ALTER TABLE `wpei_bp_messages_recipients`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wpei_bp_notifications`
--
ALTER TABLE `wpei_bp_notifications`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wpei_bp_notifications_meta`
--
ALTER TABLE `wpei_bp_notifications_meta`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wpei_bp_user_blogs`
--
ALTER TABLE `wpei_bp_user_blogs`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `wpei_bp_user_blogs_blogmeta`
--
ALTER TABLE `wpei_bp_user_blogs_blogmeta`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `wpei_bp_xprofile_data`
--
ALTER TABLE `wpei_bp_xprofile_data`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `wpei_bp_xprofile_fields`
--
ALTER TABLE `wpei_bp_xprofile_fields`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `wpei_bp_xprofile_groups`
--
ALTER TABLE `wpei_bp_xprofile_groups`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `wpei_bp_xprofile_meta`
--
ALTER TABLE `wpei_bp_xprofile_meta`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wpei_commentmeta`
--
ALTER TABLE `wpei_commentmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wpei_comments`
--
ALTER TABLE `wpei_comments`
  MODIFY `comment_ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wpei_core_metrix_ratings`
--
ALTER TABLE `wpei_core_metrix_ratings`
  MODIFY `ID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=145;

--
-- AUTO_INCREMENT for table `wpei_core_metrix_ratings_old`
--
ALTER TABLE `wpei_core_metrix_ratings_old`
  MODIFY `ID` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wpei_duplicator_packages`
--
ALTER TABLE `wpei_duplicator_packages`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wpei_links`
--
ALTER TABLE `wpei_links`
  MODIFY `link_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wpei_maxbuttonsv3`
--
ALTER TABLE `wpei_maxbuttonsv3`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `wpei_maxbuttons_collections`
--
ALTER TABLE `wpei_maxbuttons_collections`
  MODIFY `meta_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wpei_mlw_qm_audit_trail`
--
ALTER TABLE `wpei_mlw_qm_audit_trail`
  MODIFY `trail_id` mediumint(9) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wpei_mlw_questions`
--
ALTER TABLE `wpei_mlw_questions`
  MODIFY `question_id` mediumint(9) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wpei_mlw_quizzes`
--
ALTER TABLE `wpei_mlw_quizzes`
  MODIFY `quiz_id` mediumint(9) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wpei_mlw_results`
--
ALTER TABLE `wpei_mlw_results`
  MODIFY `result_id` mediumint(9) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wpei_mr_rating_item`
--
ALTER TABLE `wpei_mr_rating_item`
  MODIFY `rating_item_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `wpei_mr_rating_item_entry`
--
ALTER TABLE `wpei_mr_rating_item_entry`
  MODIFY `rating_item_entry_id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wpei_mr_rating_item_entry_value`
--
ALTER TABLE `wpei_mr_rating_item_entry_value`
  MODIFY `rating_item_entry_value_id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wpei_mr_rating_subject`
--
ALTER TABLE `wpei_mr_rating_subject`
  MODIFY `rating_id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wpei_options`
--
ALTER TABLE `wpei_options`
  MODIFY `option_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39852;

--
-- AUTO_INCREMENT for table `wpei_postmeta`
--
ALTER TABLE `wpei_postmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5660;

--
-- AUTO_INCREMENT for table `wpei_posts`
--
ALTER TABLE `wpei_posts`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1223;

--
-- AUTO_INCREMENT for table `wpei_signups`
--
ALTER TABLE `wpei_signups`
  MODIFY `signup_id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wpei_sjs_my_surveys`
--
ALTER TABLE `wpei_sjs_my_surveys`
  MODIFY `id` mediumint(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `wpei_sjs_results`
--
ALTER TABLE `wpei_sjs_results`
  MODIFY `id` mediumint(9) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wpei_survey_ratings`
--
ALTER TABLE `wpei_survey_ratings`
  MODIFY `ID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `wpei_team_poll`
--
ALTER TABLE `wpei_team_poll`
  MODIFY `ID` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wpei_termmeta`
--
ALTER TABLE `wpei_termmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `wpei_terms`
--
ALTER TABLE `wpei_terms`
  MODIFY `term_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=76;

--
-- AUTO_INCREMENT for table `wpei_term_taxonomy`
--
ALTER TABLE `wpei_term_taxonomy`
  MODIFY `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=76;

--
-- AUTO_INCREMENT for table `wpei_uji_counter`
--
ALTER TABLE `wpei_uji_counter`
  MODIFY `id` int(9) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `wpei_uji_subscriptions`
--
ALTER TABLE `wpei_uji_subscriptions`
  MODIFY `Id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wpei_usermeta`
--
ALTER TABLE `wpei_usermeta`
  MODIFY `umeta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=236;

--
-- AUTO_INCREMENT for table `wpei_users`
--
ALTER TABLE `wpei_users`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `wpei_wc_download_log`
--
ALTER TABLE `wpei_wc_download_log`
  MODIFY `download_log_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wpei_wc_webhooks`
--
ALTER TABLE `wpei_wc_webhooks`
  MODIFY `webhook_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wpei_woocommerce_api_keys`
--
ALTER TABLE `wpei_woocommerce_api_keys`
  MODIFY `key_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wpei_woocommerce_attribute_taxonomies`
--
ALTER TABLE `wpei_woocommerce_attribute_taxonomies`
  MODIFY `attribute_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wpei_woocommerce_downloadable_product_permissions`
--
ALTER TABLE `wpei_woocommerce_downloadable_product_permissions`
  MODIFY `permission_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wpei_woocommerce_log`
--
ALTER TABLE `wpei_woocommerce_log`
  MODIFY `log_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wpei_woocommerce_order_itemmeta`
--
ALTER TABLE `wpei_woocommerce_order_itemmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wpei_woocommerce_order_items`
--
ALTER TABLE `wpei_woocommerce_order_items`
  MODIFY `order_item_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wpei_woocommerce_payment_tokenmeta`
--
ALTER TABLE `wpei_woocommerce_payment_tokenmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wpei_woocommerce_payment_tokens`
--
ALTER TABLE `wpei_woocommerce_payment_tokens`
  MODIFY `token_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wpei_woocommerce_sessions`
--
ALTER TABLE `wpei_woocommerce_sessions`
  MODIFY `session_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `wpei_woocommerce_shipping_zones`
--
ALTER TABLE `wpei_woocommerce_shipping_zones`
  MODIFY `zone_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wpei_woocommerce_shipping_zone_locations`
--
ALTER TABLE `wpei_woocommerce_shipping_zone_locations`
  MODIFY `location_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wpei_woocommerce_shipping_zone_methods`
--
ALTER TABLE `wpei_woocommerce_shipping_zone_methods`
  MODIFY `instance_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wpei_woocommerce_tax_rates`
--
ALTER TABLE `wpei_woocommerce_tax_rates`
  MODIFY `tax_rate_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wpei_woocommerce_tax_rate_locations`
--
ALTER TABLE `wpei_woocommerce_tax_rate_locations`
  MODIFY `location_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wpyf_commentmeta`
--
ALTER TABLE `wpyf_commentmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wpyf_comments`
--
ALTER TABLE `wpyf_comments`
  MODIFY `comment_ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `wpyf_links`
--
ALTER TABLE `wpyf_links`
  MODIFY `link_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wpyf_options`
--
ALTER TABLE `wpyf_options`
  MODIFY `option_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=140;

--
-- AUTO_INCREMENT for table `wpyf_postmeta`
--
ALTER TABLE `wpyf_postmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `wpyf_posts`
--
ALTER TABLE `wpyf_posts`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `wpyf_termmeta`
--
ALTER TABLE `wpyf_termmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wpyf_terms`
--
ALTER TABLE `wpyf_terms`
  MODIFY `term_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `wpyf_term_taxonomy`
--
ALTER TABLE `wpyf_term_taxonomy`
  MODIFY `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `wpyf_usermeta`
--
ALTER TABLE `wpyf_usermeta`
  MODIFY `umeta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `wpyf_users`
--
ALTER TABLE `wpyf_users`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `wpei_wc_download_log`
--
ALTER TABLE `wpei_wc_download_log`
  ADD CONSTRAINT `fk_wc_download_log_permission_id` FOREIGN KEY (`permission_id`) REFERENCES `wpei_woocommerce_downloadable_product_permissions` (`permission_id`) ON DELETE CASCADE;
