
-- --------------------------------------------------------

--
-- Table structure for table `wpei_uji_counter`
--

CREATE TABLE `wpei_uji_counter` (
  `id` int(9) UNSIGNED NOT NULL,
  `time` datetime NOT NULL,
  `title` varchar(128) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `style` varchar(8) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `options` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wpei_uji_counter`
--

INSERT INTO `wpei_uji_counter` (`id`, `time`, `title`, `style`, `options`) VALUES
(1, '2018-09-04 21:19:35', 'Time till next game', 'classic', 'a:23:{s:9:\"ujic_goof\";s:13:\"Archivo Black\";s:8:\"ujic_pos\";s:6:\"center\";s:6:\"ujic_h\";s:4:\"true\";s:6:\"ujic_m\";s:4:\"true\";s:6:\"ujic_s\";s:4:\"true\";s:8:\"ujic_ani\";s:4:\"true\";s:8:\"ujic_txt\";s:4:\"true\";s:9:\"ujic_size\";s:2:\"21\";s:11:\"ujic_col_dw\";s:7:\"#000000\";s:11:\"ujic_col_up\";s:7:\"#65636b\";s:12:\"ujic_col_txt\";s:7:\"#e6ff00\";s:11:\"ujic_col_sw\";s:7:\"#828282\";s:12:\"ujic_col_lab\";s:7:\"#000000\";s:11:\"ujic_lab_sz\";s:2:\"17\";s:19:\"ujic_subscrFrmWidth\";s:3:\"100\";s:23:\"ujic_subscrFrmAboveText\";s:19:\"Join Our Newsletter\";s:23:\"ujic_subscrFrmInputText\";s:21:\"Enter your email here\";s:24:\"ujic_subscrFrmSubmitText\";s:9:\"Subscribe\";s:25:\"ujic_subscrFrmSubmitColor\";s:7:\"#ab02b2\";s:27:\"ujic_subscrFrmThanksMessage\";s:22:\"Thanks for subscribing\";s:26:\"ujic_subscrFrmErrorMessage\";s:21:\"Invalid email address\";s:16:\"ujic_secure_form\";s:10:\"ea935931b4\";s:16:\"_wp_http_referer\";s:80:\"/wp-admin/options-general.php?page=uji-countdown&amp;tab=tab_ujic_new&amp;edit=1\";}');
