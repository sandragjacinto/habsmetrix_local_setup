
-- --------------------------------------------------------

--
-- Table structure for table `wpei_termmeta`
--

CREATE TABLE `wpei_termmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `term_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wpei_termmeta`
--

INSERT INTO `wpei_termmeta` (`meta_id`, `term_id`, `meta_key`, `meta_value`) VALUES
(1, 40, 'progressbar_title', 'Team management progress'),
(2, 40, '_progressbar_title', 'field_5c0fcee66b44c');
