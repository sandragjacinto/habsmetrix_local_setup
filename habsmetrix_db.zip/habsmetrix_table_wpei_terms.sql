
-- --------------------------------------------------------

--
-- Table structure for table `wpei_terms`
--

CREATE TABLE `wpei_terms` (
  `term_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wpei_terms`
--

INSERT INTO `wpei_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(3, 'post-format-image', 'post-format-image', 0),
(4, 'Rush', 'rush', 0),
(5, 'Phil', 'phil', 0),
(9, 'page', 'page', 0),
(10, 'section', 'section', 0),
(11, 'simple', 'simple', 0),
(12, 'grouped', 'grouped', 0),
(13, 'variable', 'variable', 0),
(14, 'external', 'external', 0),
(15, 'exclude-from-search', 'exclude-from-search', 0),
(16, 'exclude-from-catalog', 'exclude-from-catalog', 0),
(17, 'featured', 'featured', 0),
(18, 'outofstock', 'outofstock', 0),
(19, 'rated-1', 'rated-1', 0),
(20, 'rated-2', 'rated-2', 0),
(21, 'rated-3', 'rated-3', 0),
(22, 'rated-4', 'rated-4', 0),
(23, 'rated-5', 'rated-5', 0),
(24, 'Uncategorized', 'uncategorized', 0),
(26, 'Countdown', 'countdown', 0),
(27, 'HABS', 'habs', 0),
(28, 'Montreal Candiens', 'montreal-candiens', 0),
(29, 'New Jursey Devils', 'new-jursey-devils', 0),
(30, 'error', 'error', 0),
(31, 'event', 'event', 0),
(39, 'Main Nav', 'main-nav', 0),
(40, 'Footer Nav', 'footer-nav', 0),
(41, 'Ex non vel non fugiat est id', 'ex-non-vel-non-fugiat-est-id', 0),
(44, 'Consequuntur', 'consequuntur', 0),
(46, 'Rerum ut sequi impedit animi mollitia corrupti molestiae', 'rerum-ut-sequi-impedit-animi-mollitia-corrupti-molestiae', 0),
(49, 'test', 'test', 0),
(51, 'activity-comment', 'activity-comment', 0),
(52, 'activity-comment-author', 'activity-comment-author', 0),
(53, 'activity-at-message', 'activity-at-message', 0),
(54, 'groups-at-message', 'groups-at-message', 0),
(55, 'core-user-registration', 'core-user-registration', 0),
(56, 'friends-request', 'friends-request', 0),
(57, 'friends-request-accepted', 'friends-request-accepted', 0),
(58, 'groups-details-updated', 'groups-details-updated', 0),
(59, 'groups-invitation', 'groups-invitation', 0),
(60, 'groups-member-promoted', 'groups-member-promoted', 0),
(61, 'groups-membership-request', 'groups-membership-request', 0),
(62, 'messages-unread', 'messages-unread', 0),
(63, 'settings-verify-email-change', 'settings-verify-email-change', 0),
(64, 'groups-membership-request-accepted', 'groups-membership-request-accepted', 0),
(65, 'groups-membership-request-rejected', 'groups-membership-request-rejected', 0),
(69, 'slider', 'slider', 0),
(72, 'trade index', 'tradeindex', 0),
(73, 'trade index', 'tradeindex', 0),
(74, 'trade index', 'trade-index', 0),
(75, 'slider', 'slider', 0);
