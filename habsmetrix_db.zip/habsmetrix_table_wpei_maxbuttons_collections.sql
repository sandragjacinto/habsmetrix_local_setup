
-- --------------------------------------------------------

--
-- Table structure for table `wpei_maxbuttons_collections`
--

CREATE TABLE `wpei_maxbuttons_collections` (
  `meta_id` int(11) NOT NULL,
  `collection_id` int(11) NOT NULL,
  `collection_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `collection_value` text COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
