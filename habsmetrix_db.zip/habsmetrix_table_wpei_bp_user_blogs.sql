
-- --------------------------------------------------------

--
-- Table structure for table `wpei_bp_user_blogs`
--

CREATE TABLE `wpei_bp_user_blogs` (
  `id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `blog_id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wpei_bp_user_blogs`
--

INSERT INTO `wpei_bp_user_blogs` (`id`, `user_id`, `blog_id`) VALUES
(1, 1, 1);
