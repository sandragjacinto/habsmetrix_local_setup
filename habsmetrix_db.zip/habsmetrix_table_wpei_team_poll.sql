
-- --------------------------------------------------------

--
-- Table structure for table `wpei_team_poll`
--

CREATE TABLE `wpei_team_poll` (
  `ID` bigint(20) NOT NULL,
  `player_id` bigint(20) NOT NULL,
  `rating` float(3,2) NOT NULL,
  `user_ip` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
