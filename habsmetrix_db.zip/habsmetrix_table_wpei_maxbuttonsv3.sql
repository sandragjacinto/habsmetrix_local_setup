
-- --------------------------------------------------------

--
-- Table structure for table `wpei_maxbuttonsv3`
--

CREATE TABLE `wpei_maxbuttonsv3` (
  `id` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'publish',
  `cache` text COLLATE utf8mb4_unicode_ci,
  `basic` text COLLATE utf8mb4_unicode_ci,
  `color` text COLLATE utf8mb4_unicode_ci,
  `dimension` text COLLATE utf8mb4_unicode_ci,
  `border` text COLLATE utf8mb4_unicode_ci,
  `gradient` text COLLATE utf8mb4_unicode_ci,
  `text` text COLLATE utf8mb4_unicode_ci,
  `container` text COLLATE utf8mb4_unicode_ci,
  `advanced` text COLLATE utf8mb4_unicode_ci,
  `responsive` text COLLATE utf8mb4_unicode_ci,
  `meta` text COLLATE utf8mb4_unicode_ci,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wpei_maxbuttonsv3`
--

INSERT INTO `wpei_maxbuttonsv3` (`id`, `name`, `status`, `cache`, `basic`, `color`, `dimension`, `border`, `gradient`, `text`, `container`, `advanced`, `responsive`, `meta`, `updated`, `created`) VALUES
(1, 'VOTE', 'publish', '.maxbutton-1.maxbutton.maxbutton-vote{position:relative !important;text-decoration:none !important;display:inline-block !important;vertical-align:middle !important;border-color:#d33 !important;width:160px !important;height:50px !important;border-top-left-radius:4px !important;border-top-right-radius:4px !important;border-bottom-left-radius:4px !important;border-bottom-right-radius:4px !important;border-style:solid !important;border-width:2px !important;background:rgba(36, 36, 229, 1) !important;-pie-background:linear-gradient(rgba(36, 36, 229, 1) 45%, rgba(80, 90, 199, 1)) !important;background:-webkit-gradient(linear, left top, left bottom, color-stop(45%, rgba(36, 36, 229, 1)), color-stop(1, rgba(80, 90, 199, 1))) !important;background:-moz-linear-gradient(rgba(36, 36, 229, 1) 45%, rgba(80, 90, 199, 1)) !important;background:-o-linear-gradient(rgba(36, 36, 229, 1) 45%, rgba(80, 90, 199, 1)) !important;background:linear-gradient(rgba(36, 36, 229, 1) 45%, rgba(80, 90, 199, 1)) !important;-webkit-box-shadow:0px 0px 9px 2px #333 !important;-moz-box-shadow:0px 0px 9px 2px #333 !important;box-shadow:0px 0px 9px 2px #333 !important}.maxbutton-1.maxbutton:hover.maxbutton-vote{border-color:#fff !important;background:rgba(255, 255, 255, 0.9) !important;-pie-background:linear-gradient(rgba(255, 255, 255, 0.9) 45%, rgba(255, 255, 255, 0.9)) !important;background:-webkit-gradient(linear, left top, left bottom, color-stop(45%, rgba(255, 255, 255, 0.9)), color-stop(1, rgba(255, 255, 255, 0.9))) !important;background:-moz-linear-gradient(rgba(255, 255, 255, 0.9) 45%, rgba(255, 255, 255, 0.9)) !important;background:-o-linear-gradient(rgba(255, 255, 255, 0.9) 45%, rgba(255, 255, 255, 0.9)) !important;background:linear-gradient(rgba(255, 255, 255, 0.9) 45%, rgba(255, 255, 255, 0.9)) !important;-webkit-box-shadow:0px 0px 9px 2px #333 !important;-moz-box-shadow:0px 0px 9px 2px #333 !important;box-shadow:0px 0px 9px 2px #333 !important}.maxbutton-1.maxbutton.maxbutton-vote .mb-text{color:#dd0404 !important;font-family:Tahoma !important;font-size:21px !important;text-align:center !important;font-style:normal !important;font-weight:bold !important;padding-top:18px !important;padding-right:0px !important;padding-bottom:0px !important;padding-left:0px !important;line-height:1em !important;box-sizing:border-box !important;display:block !important;background-color:unset !important;text-shadow:0px 0px 7px #505ac7 !important}.maxbutton-1.maxbutton:hover.maxbutton-vote .mb-text{color:#0112c6 !important;text-shadow:0px 0px 7px #333 !important}@media only screen and (max-width:480px){.maxbutton-1.maxbutton.maxbutton-vote{width:90% !important}.maxbutton-1.maxbutton.maxbutton-vote .mb-text{font-size:16px !important}}', '{\"name\":\"VOTE\",\"status\":\"publish\",\"description\":\"\",\"url\":\"www.habsmetrix.com\",\"link_title\":\"\",\"new_window\":0,\"nofollow\":0}', '{\"text_color\":\"#dd0404\",\"text_shadow_color\":\"#505ac7\",\"gradient_start_color\":\"#2424e5\",\"gradient_end_color\":\"#505ac7\",\"border_color\":\"#dd3333\",\"box_shadow_color\":\"#333333\",\"text_color_hover\":\"#0112c6\",\"text_shadow_color_hover\":\"#333333\",\"gradient_start_color_hover\":\"#ffffff\",\"gradient_end_color_hover\":\"#ffffff\",\"border_color_hover\":\"#ffffff\",\"box_shadow_color_hover\":\"#333333\",\"icon_color\":\"#ffffff\",\"icon_color_hover\":\"#2b469e\"}', '{\"button_width\":160,\"button_height\":50}', '{\"radius_top_left\":4,\"radius_top_right\":4,\"radius_bottom_left\":4,\"radius_bottom_right\":4,\"border_style\":\"solid\",\"border_width\":2,\"box_shadow_offset_left\":0,\"box_shadow_offset_top\":0,\"box_shadow_width\":9,\"box_shadow_spread\":2}', '{\"gradient_stop\":\"45\",\"gradient_start_opacity\":\"100\",\"gradient_end_opacity\":\"100\",\"gradient_start_opacity_hover\":\"90\",\"gradient_end_opacity_hover\":\"90\",\"use_gradient\":\"1\"}', '{\"text\":\"VOTE NOW!\",\"font\":\"Tahoma\",\"font_size\":21,\"text_align\":\"center\",\"font_style\":\"normal\",\"font_weight\":\"bold\",\"text_shadow_offset_left\":0,\"text_shadow_offset_top\":0,\"text_shadow_width\":7,\"padding_top\":18,\"padding_right\":0,\"padding_bottom\":0,\"padding_left\":0}', '{\"container_enabled\":\"0\",\"container_center_div_wrap\":\"0\",\"container_width\":0,\"container_margin_top\":0,\"container_margin_right\":0,\"container_margin_bottom\":0,\"container_margin_left\":0,\"container_alignment\":\"\"}', '{\"important_css\":\"1\",\"custom_rel\":\"\",\"extra_classes\":\"\",\"external_css\":\"0\"}', '{\"media_query\":[],\"auto_responsive\":\"1\"}', '{\"created\":\"1535864353\",\"modified\":1535888283,\"user_created\":\"nx2tx\",\"user_modified\":\"nx2tx\",\"created_source\":\"editor\",\"user_edited\":\"true\",\"in_collections\":[],\"is_virtual\":\"\"}', '2018-09-02 11:38:03', '2018-09-02 09:59:13');
