
-- --------------------------------------------------------

--
-- Table structure for table `wpei_mr_rating_subject`
--

CREATE TABLE `wpei_mr_rating_subject` (
  `rating_id` bigint(20) NOT NULL,
  `post_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
