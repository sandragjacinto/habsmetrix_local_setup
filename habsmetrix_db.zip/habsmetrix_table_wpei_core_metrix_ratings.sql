
-- --------------------------------------------------------

--
-- Table structure for table `wpei_core_metrix_ratings`
--

CREATE TABLE `wpei_core_metrix_ratings` (
  `ID` bigint(20) NOT NULL,
  `poll_id` bigint(20) NOT NULL,
  `poll_type` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `date` datetime NOT NULL,
  `rating` float(12,2) NOT NULL,
  `user_ip` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `user_id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wpei_core_metrix_ratings`
--

INSERT INTO `wpei_core_metrix_ratings` (`ID`, `poll_id`, `poll_type`, `date`, `rating`, `user_ip`, `user_id`) VALUES
(129, 988, 'index', '2019-02-01 06:23:41', 1.00, '::1', 1),
(130, 910, 'index', '2019-02-02 06:34:49', 0.50, '::1', 1),
(131, 988, 'index', '2019-02-02 06:34:50', 1.00, '::1', 1),
(132, 988, 'index', '2019-02-02 05:12:24', 0.00, '::1', 1),
(133, 988, 'index', '2019-02-02 05:43:20', 1.00, '::1', 1),
(134, 989, 'index', '2019-02-03 05:43:21', 1.00, '::1', 1),
(135, 928, 'index', '2019-02-03 05:43:39', 0.00, '::1', 1),
(136, 990, 'index', '2019-02-03 05:43:40', 0.50, '::1', 1),
(137, 908, 'slider', '2019-02-03 05:44:36', 8.00, '::1', 1),
(138, 1053, 'slider', '2019-02-03 05:44:37', 8.00, '::1', 1),
(139, 1212, 'slider', '2019-02-03 05:44:38', 8.00, '::1', 1),
(140, 936, 'slider', '2019-02-03 05:44:46', 13200000.00, '::1', 1),
(141, 1060, 'slider', '2019-02-03 05:44:47', 13150000.00, '::1', 1),
(142, 991, 'index', '2019-02-03 05:44:59', 1.00, '::1', 1),
(143, 988, 'index', '2019-02-03 05:55:10', 1.00, '::1', 1),
(144, 991, 'index', '2019-02-03 09:41:31', -1.00, '::1', 1);
