
-- --------------------------------------------------------

--
-- Table structure for table `wpei_mr_rating_item`
--

CREATE TABLE `wpei_mr_rating_item` (
  `rating_item_id` bigint(20) NOT NULL,
  `rating_id` bigint(20) NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `default_option_value` int(11) DEFAULT NULL,
  `max_option_value` int(11) DEFAULT NULL,
  `required` tinyint(1) DEFAULT '0',
  `active` tinyint(1) DEFAULT '1',
  `weight` double DEFAULT '1',
  `type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'select'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wpei_mr_rating_item`
--

INSERT INTO `wpei_mr_rating_item` (`rating_item_id`, `rating_id`, `description`, `default_option_value`, `max_option_value`, `required`, `active`, `weight`, `type`) VALUES
(1, 0, 'Sample rating item', 5, 5, 1, 1, 1, 'star_rating');
