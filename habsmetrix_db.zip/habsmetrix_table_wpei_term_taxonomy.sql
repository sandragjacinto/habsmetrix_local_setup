
-- --------------------------------------------------------

--
-- Table structure for table `wpei_term_taxonomy`
--

CREATE TABLE `wpei_term_taxonomy` (
  `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL,
  `term_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wpei_term_taxonomy`
--

INSERT INTO `wpei_term_taxonomy` (`term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 6),
(3, 3, 'post_format', '', 0, 0),
(4, 4, 'post_tag', '', 0, 0),
(5, 5, 'post_tag', '', 0, 0),
(9, 9, 'elementor_library_type', '', 0, 7),
(10, 10, 'elementor_library_type', '', 0, 2),
(11, 11, 'product_type', '', 0, 0),
(12, 12, 'product_type', '', 0, 0),
(13, 13, 'product_type', '', 0, 0),
(14, 14, 'product_type', '', 0, 0),
(15, 15, 'product_visibility', '', 0, 0),
(16, 16, 'product_visibility', '', 0, 0),
(17, 17, 'product_visibility', '', 0, 0),
(18, 18, 'product_visibility', '', 0, 0),
(19, 19, 'product_visibility', '', 0, 0),
(20, 20, 'product_visibility', '', 0, 0),
(21, 21, 'product_visibility', '', 0, 0),
(22, 22, 'product_visibility', '', 0, 0),
(23, 23, 'product_visibility', '', 0, 0),
(24, 24, 'product_cat', '', 0, 0),
(26, 26, 'post_tag', '', 0, 0),
(27, 27, 'post_tag', '', 0, 0),
(28, 28, 'post_tag', '', 0, 0),
(29, 29, 'post_tag', '', 0, 0),
(30, 30, 'qmn_log_type', '', 0, 0),
(31, 31, 'qmn_log_type', '', 0, 0),
(39, 39, 'nav_menu', '', 0, 12),
(40, 40, 'nav_menu', '', 0, 0),
(41, 41, 'post_tag', 'Rerum modi quis quas corporis animi sit quasi earum quae numquam optio et pariatur vero provident officia quidem quo perspiciatis accusamus delectus dolorum ut architecto distinctio', 0, 0),
(44, 44, 'post_tag', 'Et sapiente dolore vel ex accusantium', 0, 0),
(46, 46, 'post_tag', 'Facere sed aut ut impedit commodi quo voluptatibus et id et corporis soluta et vel quos et', 0, 0),
(49, 49, 'post_tag', '', 0, 0),
(51, 51, 'bp-email-type', 'A member has replied to an activity update that the recipient posted.', 0, 1),
(52, 52, 'bp-email-type', 'A member has replied to a comment on an activity update that the recipient posted.', 0, 1),
(53, 53, 'bp-email-type', 'Recipient was mentioned in an activity update.', 0, 1),
(54, 54, 'bp-email-type', 'Recipient was mentioned in a group activity update.', 0, 1),
(55, 55, 'bp-email-type', 'Recipient has registered for an account.', 0, 1),
(56, 56, 'bp-email-type', 'A member has sent a friend request to the recipient.', 0, 1),
(57, 57, 'bp-email-type', 'Recipient has had a friend request accepted by a member.', 0, 1),
(58, 58, 'bp-email-type', 'A group\'s details were updated.', 0, 1),
(59, 59, 'bp-email-type', 'A member has sent a group invitation to the recipient.', 0, 1),
(60, 60, 'bp-email-type', 'Recipient\'s status within a group has changed.', 0, 1),
(61, 61, 'bp-email-type', 'A member has requested permission to join a group.', 0, 1),
(62, 62, 'bp-email-type', 'Recipient has received a private message.', 0, 1),
(63, 63, 'bp-email-type', 'Recipient has changed their email address.', 0, 1),
(64, 64, 'bp-email-type', 'Recipient had requested to join a group, which was accepted.', 0, 1),
(65, 65, 'bp-email-type', 'Recipient had requested to join a group, which was rejected.', 0, 1),
(69, 69, 'category', '', 0, 1),
(72, 72, 'category', '', 0, 0),
(73, 73, 'trade_index', '', 0, 0),
(74, 74, 'core_metrix', '', 0, 0),
(75, 75, 'core_metrix', '', 0, 0);
