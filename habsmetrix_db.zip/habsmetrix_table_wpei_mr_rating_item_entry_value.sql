
-- --------------------------------------------------------

--
-- Table structure for table `wpei_mr_rating_item_entry_value`
--

CREATE TABLE `wpei_mr_rating_item_entry_value` (
  `rating_item_entry_value_id` bigint(20) NOT NULL,
  `rating_item_entry_id` bigint(20) NOT NULL,
  `rating_item_id` bigint(20) NOT NULL,
  `value` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
