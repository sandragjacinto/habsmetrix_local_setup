
-- --------------------------------------------------------

--
-- Table structure for table `wpei_maxbuttons_collections_trans`
--

CREATE TABLE `wpei_maxbuttons_collections_trans` (
  `name` varchar(1000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `value` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expire` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
