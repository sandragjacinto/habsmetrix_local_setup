
-- --------------------------------------------------------

--
-- Table structure for table `wpei_users`
--

CREATE TABLE `wpei_users` (
  `ID` bigint(20) UNSIGNED NOT NULL,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wpei_users`
--

INSERT INTO `wpei_users` (`ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'nx2tx', '$P$BjDZEWshvVDV.aHHgZ7rzzMbt108VT/', 'nx2tx', 'admin@habsmetrix.com', 'http://www.habsmetrix.com', '2018-08-31 15:34:17', '1536068208:$P$BESY0YtCRgvftLen77Q4nhydZ9gEcS0', 0, 'Philip'),
(2, 'lakeshallewelyn', '$P$B6ZCMbqM3cSuSrevw94jCJQ0yOcDUh/', 'lakeshallewelyn', 'lakesha-llewelyn25@sholtis.junkcarsfloridamiami.com', '', '2018-09-14 06:50:40', '1536907840:$P$BgW2E5iuDKUPEDQZMlgwZPZH5q4CKO0', 0, 'lakeshallewelyn'),
(3, 'cleodowney8', '$P$BSkzhP2D3dHAz6RFkhbwD3/yqVEdX90', 'cleodowney8', 'cleo.downey@sholtis.junkcarsfloridamiami.com', '', '2018-09-14 08:25:49', '1536913549:$P$B0LJouHe634/37JcQx.X8m2ytJPy/N/', 0, 'cleodowney8'),
(4, 'darelllemos84', '$P$B1RpIW.NGhIZYsgMKUNRI0FHctDOxg.', 'darelllemos84', 'darell_lemos89@worchester43.softhandscream.com', '', '2018-09-14 09:24:46', '1536917086:$P$Bs3dMPbHKEFu7VzAVsaqaguwK5Gcp40', 0, 'darelllemos84'),
(5, 'quyenmendenhall', '$P$BJ52ap1DAs6tUkt273xr/HQWaazPxr/', 'quyenmendenhall', 'quyen_mendenhall69@patry.spicysallads.com', '', '2018-09-14 09:46:22', '1536918382:$P$BU6cZg5NRX4HPSv0mSuCVke/i.GOvG0', 0, 'quyenmendenhall'),
(6, 'fgrimes', '$P$BoMHutSMJJsKZ5bXkQXxVmTpQNVwyQ.', 'ortiz-leon', 'nona.marvin@example.com', 'http://weber.com/id-est-totam-consequatur-nihil-quia-ut-explicabo', '2018-10-07 03:47:32', '', 0, 'Bell'),
(7, 'dubuque.enid', '$P$B5QwLwkdIvehuBX28eHtRAiel3cq21.', 'brooke-brakus', 'dooley.angelita@example.com', 'http://www.tromp.net/ut-perferendis-iste-id-non-quos', '2018-10-07 13:28:51', '', 0, 'Frida'),
(8, 'test', '$P$BZb8F/4j6hwB7sigxwPYG.uSlPQjOc0', 'test', 'test@gmail.com', '', '2018-11-27 15:36:41', '', 0, 'test'),
(9, 'smouska', '$P$BuwZXDo7XZWmucEEPiX04TR3tyFBFA1', 'smouska', 'sandragjacinto@gmail.com', '', '2019-01-09 17:25:29', '1547054729:$P$BqEuyz6PnTuCafmvd6D42kSgt../XP0', 0, 'smouska'),
(10, 'sandritah_05@hotmail.com', '$P$BVkkQQPl82MzRL682FH.Mk/S9K712s1', 'sandritah_05hotmail-com', 'sandritah_05@hotmail.com', '', '2019-01-17 08:47:10', '1547714830:$P$BLUS7whojt29UBjvqGepag2gYPXXWt.', 0, 'sandritah_05@hotmail.com');
