
-- --------------------------------------------------------

--
-- Table structure for table `wpei_bp_activity_meta`
--

CREATE TABLE `wpei_bp_activity_meta` (
  `id` bigint(20) NOT NULL,
  `activity_id` bigint(20) NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wpei_bp_activity_meta`
--

INSERT INTO `wpei_bp_activity_meta` (`id`, `activity_id`, `meta_key`, `meta_value`) VALUES
(1, 2, 'post_title', 'Iusto et ut explicabo assumenda quia'),
(2, 2, 'post_url', 'http://localhost:8888/habsmetrix/?p=631'),
(3, 3, 'post_title', 'Sint nihil harum architecto qui saepe'),
(4, 3, 'post_url', 'http://localhost:8888/habsmetrix/?p=646');
