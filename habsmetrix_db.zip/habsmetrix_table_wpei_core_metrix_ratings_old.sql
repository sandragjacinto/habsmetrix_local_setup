
-- --------------------------------------------------------

--
-- Table structure for table `wpei_core_metrix_ratings_old`
--

CREATE TABLE `wpei_core_metrix_ratings_old` (
  `ID` bigint(20) NOT NULL,
  `poll_id` bigint(20) NOT NULL,
  `poll_type` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `date` datetime NOT NULL,
  `rating` float(12,2) NOT NULL,
  `user_ip` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `user_id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
