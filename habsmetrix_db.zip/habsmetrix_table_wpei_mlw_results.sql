
-- --------------------------------------------------------

--
-- Table structure for table `wpei_mlw_results`
--

CREATE TABLE `wpei_mlw_results` (
  `result_id` mediumint(9) NOT NULL,
  `quiz_id` int(11) NOT NULL,
  `quiz_name` text NOT NULL,
  `quiz_system` int(11) NOT NULL,
  `point_score` int(11) NOT NULL,
  `correct_score` int(11) NOT NULL,
  `correct` int(11) NOT NULL,
  `total` int(11) NOT NULL,
  `name` text NOT NULL,
  `business` text NOT NULL,
  `email` text NOT NULL,
  `phone` text NOT NULL,
  `user` int(11) NOT NULL,
  `user_ip` text NOT NULL,
  `time_taken` text NOT NULL,
  `time_taken_real` datetime NOT NULL,
  `quiz_results` text NOT NULL,
  `deleted` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
