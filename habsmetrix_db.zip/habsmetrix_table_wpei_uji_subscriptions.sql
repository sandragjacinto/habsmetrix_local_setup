
-- --------------------------------------------------------

--
-- Table structure for table `wpei_uji_subscriptions`
--

CREATE TABLE `wpei_uji_subscriptions` (
  `Id` int(10) UNSIGNED NOT NULL,
  `EmailAddress` varchar(64) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `ProviderId` tinyint(3) UNSIGNED DEFAULT '0',
  `List` varchar(128) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `ListGroup` varchar(32) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `CreatedDate` datetime NOT NULL,
  `IsSynchronized` tinyint(3) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
