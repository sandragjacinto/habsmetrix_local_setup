
-- --------------------------------------------------------

--
-- Table structure for table `wpei_mlw_questions`
--

CREATE TABLE `wpei_mlw_questions` (
  `question_id` mediumint(9) NOT NULL,
  `quiz_id` int(11) NOT NULL,
  `question_name` text NOT NULL,
  `answer_array` text NOT NULL,
  `answer_one` text NOT NULL,
  `answer_one_points` int(11) NOT NULL,
  `answer_two` text NOT NULL,
  `answer_two_points` int(11) NOT NULL,
  `answer_three` text NOT NULL,
  `answer_three_points` int(11) NOT NULL,
  `answer_four` text NOT NULL,
  `answer_four_points` int(11) NOT NULL,
  `answer_five` text NOT NULL,
  `answer_five_points` int(11) NOT NULL,
  `answer_six` text NOT NULL,
  `answer_six_points` int(11) NOT NULL,
  `correct_answer` int(11) NOT NULL,
  `question_answer_info` text NOT NULL,
  `comments` int(11) NOT NULL,
  `hints` text NOT NULL,
  `question_order` int(11) NOT NULL,
  `question_type` int(11) NOT NULL,
  `question_type_new` text NOT NULL,
  `question_settings` text NOT NULL,
  `category` text NOT NULL,
  `deleted` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
