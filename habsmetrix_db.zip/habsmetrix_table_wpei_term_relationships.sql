
-- --------------------------------------------------------

--
-- Table structure for table `wpei_term_relationships`
--

CREATE TABLE `wpei_term_relationships` (
  `object_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wpei_term_relationships`
--

INSERT INTO `wpei_term_relationships` (`object_id`, `term_taxonomy_id`, `term_order`) VALUES
(243, 9, 0),
(246, 9, 0),
(249, 9, 0),
(255, 10, 0),
(261, 9, 0),
(264, 9, 0),
(267, 9, 0),
(271, 9, 0),
(429, 10, 0),
(631, 1, 0),
(646, 1, 0),
(659, 1, 0),
(664, 1, 0),
(679, 1, 0),
(679, 49, 0),
(688, 1, 0),
(690, 1, 0),
(715, 51, 0),
(716, 52, 0),
(717, 53, 0),
(718, 54, 0),
(719, 55, 0),
(720, 56, 0),
(721, 57, 0),
(722, 58, 0),
(723, 59, 0),
(724, 60, 0),
(725, 61, 0),
(726, 62, 0),
(727, 63, 0),
(728, 64, 0),
(729, 65, 0),
(846, 69, 0),
(849, 72, 0),
(870, 10, 0),
(1021, 39, 0),
(1030, 39, 0),
(1031, 39, 0),
(1044, 39, 0),
(1045, 39, 0),
(1046, 39, 0),
(1047, 39, 0),
(1049, 39, 0),
(1050, 39, 0),
(1135, 39, 0),
(1136, 39, 0),
(1170, 39, 0);
