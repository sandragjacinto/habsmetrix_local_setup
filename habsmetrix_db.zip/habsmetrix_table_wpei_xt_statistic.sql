
-- --------------------------------------------------------

--
-- Table structure for table `wpei_xt_statistic`
--

CREATE TABLE `wpei_xt_statistic` (
  `ip` varchar(20) NOT NULL DEFAULT '',
  `date` date NOT NULL,
  `views` int(10) NOT NULL DEFAULT '1',
  `online` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
