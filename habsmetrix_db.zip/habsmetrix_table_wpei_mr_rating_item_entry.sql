
-- --------------------------------------------------------

--
-- Table structure for table `wpei_mr_rating_item_entry`
--

CREATE TABLE `wpei_mr_rating_item_entry` (
  `rating_item_entry_id` bigint(20) NOT NULL,
  `post_id` bigint(20) NOT NULL,
  `entry_date` datetime NOT NULL,
  `user_id` bigint(20) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
