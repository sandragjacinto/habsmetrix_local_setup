
-- --------------------------------------------------------

--
-- Table structure for table `wpei_mlw_qm_audit_trail`
--

CREATE TABLE `wpei_mlw_qm_audit_trail` (
  `trail_id` mediumint(9) NOT NULL,
  `action_user` text NOT NULL,
  `action` text NOT NULL,
  `time` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
